// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    projectId: 'fir-project-f35c0',
    appId: '1:747381330965:web:11688a755c01fd200d2a1c',
    storageBucket: 'fir-project-f35c0.appspot.com',
    apiKey: 'AIzaSyAZl-jZrWmNI4rdlyH0AgaBZ-VBPPLBM98',
    authDomain: 'fir-project-f35c0.firebaseapp.com',
    messagingSenderId: '747381330965',
  }

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
