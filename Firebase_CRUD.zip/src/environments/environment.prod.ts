export const environment = {
  production: true,
  firebase: {
    projectId: 'fir-project-f35c0',
    appId: '1:747381330965:web:11688a755c01fd200d2a1c',
    storageBucket: 'fir-project-f35c0.appspot.com',
    apiKey: 'AIzaSyAZl-jZrWmNI4rdlyH0AgaBZ-VBPPLBM98',
    authDomain: 'fir-project-f35c0.firebaseapp.com',
    messagingSenderId: '747381330965',
  }
  
};
