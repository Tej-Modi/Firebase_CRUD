export interface Student {
    id: any,
    first_name: string,
    last_name: string,
    email: string,
    mobile: string,
    age: string
}