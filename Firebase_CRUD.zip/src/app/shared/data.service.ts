import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Student } from '../model/student';
import { ToastrService } from 'ngx-toastr';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private firestore: AngularFirestore, private toastr: ToastrService) { }

  //add student
  onAddStudent(student: Student) {
    student.id = this.firestore.createId();
    return this.firestore.collection('/students').add(student);
  }

  //login or not
  isLoggedIn() {
    return localStorage.getItem('token')
  }

  //get all students
  getAllStudents() {
    return this.firestore.collection('/students').snapshotChanges();
  }

  //delete student
  deleteStudent(student: Student) {
    return this.firestore.doc('/students/' + student.id).delete();
  }

  //update student
  onUpdate(student: Student) {
    console.log("student.id", student.id);
      return this.firestore.doc('/students/' + student.id).update(student);
  }
}
