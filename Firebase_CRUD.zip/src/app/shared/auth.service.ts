import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';
import { GoogleAuthProvider } from '@angular/fire/auth';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private fireauth: AngularFireAuth, private router: Router, private toastr: ToastrService) { }

  IsLoggedIn() {
    return !!localStorage.getItem('token');
  }

  //login method
  login(email: any, password: any) {
    this.fireauth.signInWithEmailAndPassword(email,password).then(res => {
      localStorage.setItem('token', 'true');
      localStorage.setItem('displayName', JSON.stringify(res.user))
      this.toastr.success('LoggedIn Successfully');
      this.router.navigate(['/dashboard']);

      if(res.user?.emailVerified == true) {
        this.router.navigate(['/dashboard']);
      }
      //  else {
      //   this.router.navigate(['/verify-email']);
      // }

    }, err => {
      alert(err.message);
      this.router.navigate(['/login']);
    })
  }

  //register method
  register(email: any, password: any, firstName: any, lastName: any, age: any, mobile: any) {
    this.fireauth.createUserWithEmailAndPassword(email,password).then((res) => {
      this.toastr.success('Registered Successfully');
      this.router.navigate(['/login']);
      this.sendEmailForVerification(res.user);
    }, err => {
      alert(err.message);
      this.router.navigate(['/register']);
    })
  }

  //forgot Password method
  forgotPassword(email: any) {
    this.fireauth.sendPasswordResetEmail(email).then(() => {
      this.router.navigate(['/verify-email']);
    }, err => {
      this.toastr.error('Something went wrong');
    })
  }

  //Email Verification
  sendEmailForVerification(user: any) {
    user.sendEmailVerification().then((res: any) => {
      this.router.navigate(['/verify-email']);
    }, (err: any) => {
      this.toastr.error('Something went wrong. Not able to mail to your email.');
    })
  }

  //Sign in with google
  googleSignIn() {
    return this.fireauth.signInWithPopup(new GoogleAuthProvider).then(res => {

      this.router.navigate(['/dashboard']);
      localStorage.setItem('token', JSON.stringify(res.user?.uid));

    }, err => {
      alert(err.message)
    })
  }
 }
