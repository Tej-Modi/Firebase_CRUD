import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { AuthService } from './../../shared/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  hide = true;
  isSubmitted = false;
  registerForm: FormGroup = new FormGroup({});
  constructor(private router: Router, private auth: AuthService, private toastr: ToastrService) {}

  ngOnInit(): void {

    this.registerForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(15)
      ]),
    });
  }

  get email() {
    return this.registerForm.get('email');
  }

  get password() {
    return this.registerForm.get('password');
  }

  onSubmit() {
    this.isSubmitted = true;
    let data = this.registerForm.value;
    
    
      if(this.registerForm.valid) {
        
        this.auth.login(data.email, data.password);
        this.router.navigate(['/dashboard']);
      }   
  }

  signInWithGoogle() {
    this.auth.googleSignIn();
  }

}
