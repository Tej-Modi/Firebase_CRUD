import { Component, OnInit } from '@angular/core';
import { AuthService } from './../../shared/auth.service';
import { FormControl, FormGroup, Validators} from '@angular/forms';



@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {


  isSubmitted = false;
  registerForm: FormGroup = new FormGroup({});


  constructor(private auth: AuthService) { }

  ngOnInit(): void {

    this.registerForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email])

    });
  }

  get email() {
    return this.registerForm.get('email');
  }

  forgotPassword() {
    let data = this.registerForm.value;
    this.auth.forgotPassword(data.email);
    this.registerForm.reset();
  }

}
