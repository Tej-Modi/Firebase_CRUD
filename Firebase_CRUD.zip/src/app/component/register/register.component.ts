import { AuthService } from './../../shared/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  

  hide = true;
  isSubmitted = false;
  registerForm: FormGroup = new FormGroup({});

  
  constructor(private router: Router, private auth: AuthService, private toastr: ToastrService) { }

  ngOnInit(): void {
    

    this.registerForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(15)
      ]),
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      age: new FormControl('', [Validators.required]),
      mobile: new FormControl('',[
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ])
    });
  }

  get email() {
    return this.registerForm.get('email');
  }

  get password() {
    return this.registerForm.get('password');
  }

  get firstName() {
    return this.registerForm.get('firstName');
  }

  get lastName() {
    return this.registerForm.get('lastName');
  } 

  get age() {
    return this.registerForm.get('age');
  } 

  get mobile() {
    return this.registerForm.get('mobile');
  }

  onSubmit() {
    this.isSubmitted = true;
    let data = this.registerForm.value;
    
      if(this.registerForm.valid) {
        
          this.auth.register(data.email, data.password, data.firstName, data.lastName, data.age, data.mobile);
          this.router.navigate(['/login'])
          
      }
  }
}
